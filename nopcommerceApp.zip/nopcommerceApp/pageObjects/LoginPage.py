# from selenium import webdriver
from selenium.webdriver.common.by import By
# from selenium.webdriver.common.action_chains import ActionChains
#
# class LoginPage:
#     signin_class ="nav-link-accountList"
#     textbox_username_id = "ap_email"
#     continue_button_id = "continue"
#     textbox_password_id = "ap_password"
#     signin_button_id = "signInSubmit"
#     button_login_xpath = '/html/body/div[6]/div/div/div/div/div[2]/div[1]/div/form/div[3]/button'
#     link_logout_linktext = 'Logout'
#     login_text_id = 'nav-link-accountList-nav-line-1'
#     account_list_id = "nav-link-accountList"
#     signout_id = "nav-item-signout"
#
#
#     def __init__(self,driver):
#         self.driver=driver
#         self.actions=ActionChains(self.driver)
#
#     def signin_arrow(self):
#         self.driver.find_element(By.ID, self.signin_class).click()
#
#
#     def setUserName(self,username):
#         # driver.find_element(By.ID, 'id-search-field')
#         self.driver.find_element(By.ID,self.textbox_username_id).clear()
#         self.driver.find_element(By.ID,self.textbox_username_id).send_keys(username)
#         self.driver.find_element(By.ID, self.continue_button_id).click()
#
#     def setPassword(self,password):
#         self.driver.find_element(By.ID,self.textbox_password_id).clear()
#         self.driver.find_element(By.ID,self.textbox_password_id).send_keys(password)
#
#
#     def clickLogin(self):
#         self.driver.find_element(By.ID, self.signin_button_id).click()
#
#     def clickLogout(self):
#         account_list = self.driver.find_element(By.ID,self.account_list_id)
#         signout = self.driver.find_element(By.ID, self.signout_id)
#         self.actions.move_to_element(account_list).move_to_element(signout).click().perform()
#
#     def checklogin(self):
#         login_text = self.driver.find_element(By.ID,self.login_text_id).text
#         return login_text
#
#
#











class LoginPage:
    # Login Page
    textbox_username_id = "Email"
    textbox_password_id = "Password"
    button_login_xpath = "//div//button[@class='button-1 login-button']"
    link_logout_linktext = "Logout"

    def __init__(self,driver):
        self.driver=driver

    def setUserName(self, username):
        self.driver.find_element(By.ID,self.textbox_username_id).clear()
        self.driver.find_element(By.ID,self.textbox_username_id).send_keys(username)

    def setPassword(self, password):
        self.driver.find_element(By.ID,self.textbox_password_id).clear()
        self.driver.find_element(By.ID,self.textbox_password_id).send_keys(password)

    def clickLogin(self):
        self.driver.find_element(By.XPATH,self.button_login_xpath).click()

    def clickLogout(self):
        self.driver.find_element(By.LINK_TEXT,self.link_logout_linktext).click()