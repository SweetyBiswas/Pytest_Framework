import time

import pytest
from selenium import webdriver
from pageObjects.LoginPage import LoginPage
from utilities.readProperties import ReadConfig
from utilities.customLogger import LogGen

class Test_001_Login:
    baseURL = ReadConfig.getApplicationURL()
    useremail = ReadConfig.getUseremail()
    password = ReadConfig.getPassword()

    logger = LogGen.loggen()
#above all variables are class variable so if we want to access those variable we need access by self.


    @pytest.mark.regression
    def test_homePageTitle(self,setup):
        self.logger.info('---------------------- Test_001_Login -----------------------------')
        self.logger.info('---------------------- Verifying Home Page Title -----------------------------')
        self.driver=setup #loungh my browser
        self.driver.get(self.baseURL)
        act_title = self.driver.title

        if act_title == "Online Shopping site in India: Shop Online for Mobiles, Books, Watches, Shoes and More - Amazon.in":
            assert True
            self.driver.close()
            self.logger.info('---------------------- Home page title test is passed -----------------------------')
        else:
            self.driver.save_screenshot(".\\Screenshots\\"+"test_homePageTitle.png")
            self.driver.close()
            self.logger.error('---------------------- Home page title test is failes -----------------------------')
            assert False


    @pytest.mark.sanity
    @pytest.mark.regression
    def test_login(self,setup):
        self.logger.info('---------------------- Verifing Login Test -----------------------------')
        self.driver=setup #loungh my browser
        self.driver.get(self.baseURL)
        self.lp=LoginPage(self.driver)
        self.lp.signin_arrow()
        self.lp.setUserName(self.useremail)
        self.lp.setPassword(self.password)
        self.lp.clickLogin()

        act_text = self.lp.checklogin()
        #act_title = self.driver.title
        if act_text == "Hello, Sweety":
            assert True
            self.logger.info('---------------------- Login test passed -----------------------------')
            self.driver.close()
        else:
            self.driver.save_screenshot(".\\Screenshots\\" + "test_login.png")
            self.driver.close()
            self.logger.error('---------------------- Login test is failed -----------------------------')
            assert False
