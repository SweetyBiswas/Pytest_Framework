#conftest.py file responsible for loanching browser

import pytest
from selenium import webdriver

@pytest.fixture()
def setup(browser): # whatever 'def browser(request)' fixture return the browser name,setup methos getting that value
    if browser=='chrome':
        driver=webdriver.Chrome()
        print("...........Launching chrome browser.........")
    elif browser=='firefox':
        driver = webdriver.Firefox()
        print("............Launching firefox browser.........")
    else:
        driver = webdriver.Ie()
    return driver

#to get the browser from command prompt
def pytest_addoption(parser):    # This will get the value from CLI /hooks
    parser.addoption("--browser")


#from the command line whatever browser name we are passing , it will get it
#and once you get it into the variable ("--browser") ,we have to pass that browser name to the setup method because
#setup method will decide which browser will launch and to do this we need to create one more fixture

# whatever the browser name we have passed through command prompt , 'pytest_addoption' - method will get that ,
# after getting the browser name into ("--browser") this variable , 'browser(request)' - method will send the same variable value to the setup method,
# so it will return 'request.config.getoption("--browser")' - means it will return the browser value to the setup method
#'pytest -v -s testCases\test_login.py --browser firefox' or 'pytest -v -s testCases\test_login.py --browser chrome ' commands we need to use to run through terminal, if we  dont pass '--browser chrome/firefox' it will throgh error.
# for that error handling we provide else part for default browser we use Internet Explorer
@pytest.fixture()
def browser(request):  # This will return the Browser value to setup method
    return request.config.getoption("--browser")


# -------------------- To Generate Pytest HTML Reports -----------------

# It is hook for Adding Environment info to HTML Report
def pytest_configure(config):
    config._metadata['Project Name'] = 'nop Commerce'
    config._metadata['Module Name'] = 'Customers'
    config._metadata['Tester'] = 'Sweety'

# It is hook for delete/Modify Environment info to HTML Report
@pytest.mark.optionalhook
def pytest_metadata(metadata):
    metadata.pop("JAVA_HOME", None)
    metadata.pop("Plugins", None)